# Android-challenge-phase-1
Challenge solution by Rasheed
